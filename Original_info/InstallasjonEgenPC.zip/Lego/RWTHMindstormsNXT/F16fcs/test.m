clc

for i = 1:25
    for j = 1:15
        for k = 1:7
            k+7*((j-1)+15*(i-1))
        end
    end
end