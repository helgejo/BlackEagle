function SetPower(hObj)
    mA.Power = get(hObj,'Value');
end
